﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GOTQUOTES
{
    class GameOfThronesAPI
    {
        public string quote { get; set; }
        public string character { get; set; }
    }
}
