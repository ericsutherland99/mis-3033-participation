﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChuckNorris
{
    class Chuck
    {
        public string value { get; set; }
        public string[] categories { get; set; }
    }
}
